package project.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import project.model.User;


public interface UserRepository extends MongoRepository<User, String>{
    
}
